Config = {}

Config.Used = "You have used a bullshark!"

Config.Health = 200  --[Suggest you leave]
Config.Armour = 100  --[Suggest you leave]

Config.Time = 20000 --[IT IS IN MILLI-SECONDS]

Config.Weapon = {
    Gun = 'weapon_appistol', -- set to false or a diff weapon if you want
    Ammo = 200
}