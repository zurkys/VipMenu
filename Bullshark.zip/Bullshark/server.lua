ESX = nil
TriggerEvent('esx:getSharedObject', function(obj)
	ESX = obj
end)
ESX.RegisterUsableItem('bullshark', function(source) 
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	xPlayer.removeInventoryItem('bullshark', 1)
	TriggerClientEvent('zurkys:bullshark', source)
end)