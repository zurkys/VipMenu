ESX = nil
local PlayerData = {}
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)
RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
end)
TriggerEvent('esx:getSharedObject', function(obj)
	ESX = obj
end)
RegisterNetEvent('zurkys:bullshark')
AddEventHandler('zurkys:bullshark', function()
  
  local playerPed = GetPlayerPed(-1)
  local playerPed = PlayerPedId()
  
    RequestAnimSet("MOVE_M@QUICK") 
    while not HasAnimSetLoaded("MOVE_M@QUICK") do
      Wait(0)
    end    
    TriggerEvent('esx_inventoryhud:closeInventory')
    ESX.ShowNotification(Config.Used, true)
    TaskStartScenarioInPlace(playerPed, "WORLD_HUMAN_DRUG_DEALER", 0, 1)
    Wait(3000)
    TriggerEvent("cS.banner", "BullShark Activated","",2, 6, false)
    GiveWeaponToPed(GetPlayerPed(-1), Config.Weapon.Gun, Config.Weapon.Ammo, false, true)
    SetWeaponDamageMultiplier(player, 10)
    ClearPedTasksImmediately(playerPed)
    SetPedArmour(playerPed, Config.Armour)
    SetEntityHealth(PlayerPedId(),Config.Health)
    SetTimecycleModifier("spectator5")
    SetPedMotionBlur(playerPed, true)
    SetPedMovementClipset(playerPed, "MOVE_M@QUICK", true)
	SetPedMoveRateOverride(PlayerId(),10)
    SetRunSprintMultiplierForPlayer(PlayerId(),1.49)
   AnimpostfxPlay("DrugsMichaelAliensFight", 10000001, true)
    Wait(Config.Time)
    SetPedMoveRateOverride(PlayerId(),1.0)
    SetRunSprintMultiplierForPlayer(PlayerId(),1.0)
    SetPedMotionBlur(playerPed, false)
    ResetPedMovementClipset(GetPlayerPed(-1))
    AnimpostfxStopAll()
    SetTimecycleModifierStrength(0.0)
end)