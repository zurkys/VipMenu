INSERT INTO `items` (name, label) VALUES
  ('bullshark','BullShark')
;