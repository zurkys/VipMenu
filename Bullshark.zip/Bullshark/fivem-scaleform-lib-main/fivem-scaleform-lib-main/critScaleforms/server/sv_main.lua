print('+------------------------------+')
print('+  CritteRs Scaleforms loaded  +')
print('+------------------------------+')