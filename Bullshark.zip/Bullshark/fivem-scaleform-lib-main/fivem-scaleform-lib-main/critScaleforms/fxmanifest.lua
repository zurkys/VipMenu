fx_version 'cerulean'
game 'gta5'

author 'CritteR / CritteRo'
description 'A coletion of scaleforms that can be integrated easily in your scripts.'

client_scripts {
    'client/cl_scaleform_functions.lua',
    'client/cl_main.lua',
    'client/cl_examples.lua',
}

server_scripts {
    'server/sv_main.lua'
}