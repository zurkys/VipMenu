fx_version 'bodacious'
game 'gta5'
author 'zurkys#1020'
lua54 'yes'
version '1.0.0'
description 'BullShark'

client_scripts {
	'Config.lua',			-- Configuration.
	'client.lua',
}

server_scripts {
	'Config.lua',			-- Configuration.
	'server.lua',
}

escrow_ignore {
    'config.lua',  ----Leave :)
	'readme.md' 
  }