USE "fivem-scaleform-lib-main" IF YOU WANT THE BANNER POPPING UP LIKE IN THE VIDEO!
THATS ALL, THANK YOU FOR PURCHASING :))

- Join discord if u need help


discord.gg/donte
discord.gg/donte
discord.gg/donte
